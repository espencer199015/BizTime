/** Database setup for BizTime. */

